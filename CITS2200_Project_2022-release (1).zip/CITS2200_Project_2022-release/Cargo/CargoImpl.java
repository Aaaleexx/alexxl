// Full Name (StudentNum), Full Name (StudentNum)

/**
 * An implementation of the Cargo problem from the 2022 CITS2200 Project
 */
public class CargoImpl implements Cargo {
  /**
   * {@inheritdoc}
   */
  public int[] departureMasses(int stops, Query[] queries) {
    // TODO: Implement your solution
    return null;
  }
}