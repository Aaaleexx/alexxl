// Full Name (StudentNum), Full Name (StudentNum)

/**
 * An implementation of the Shallows problem from the 2022 CITS2200 Project
 */
public class ShallowsImpl implements Shallows {
  /**
   * {@inheritdoc}
   */
  public int[] maximumDraughts(int ports, Lane[] lanes, int origin) {
    // TODO: Implement your solution
    return null;
  }
}