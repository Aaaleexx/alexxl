// Full Name (StudentNum), Full Name (StudentNum)

/**
 * An implementation of the Subsidiaries problem from the 2022 CITS2200 Project
 */
public class SubsidiariesImpl implements Subsidiaries {
  /**
   * {@inheritdoc}
   */
  public int[] sharedOwners(int[] owners, Query[] queries) {
    // TODO: Implement your solution
    return null;
  }
}