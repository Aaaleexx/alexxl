// Full Name (StudentNum), Full Name (StudentNum)

/**
 * An implementation of the Fines problem from the 2022 CITS2200 Project
 */
public class FinesImpl implements Fines {
  /**
   * {@inheritdoc}
   */
  public int countFines(int[] priorities) {
    // TODO: Implement your solution
    return -1;
  }
}